package com.accounts.model;

public class TransferDetails {
	
	private int saccount;
	private int raccount;
	private int amount;
	
	public int getSaccount() {
		return saccount;
	}
	
	public void setSaccount(int saccount) {
		this.saccount = saccount;
	}
	
	public int getRaccount() {
		return raccount;
	}
	
	public void setRaccount(int raccount) {
		this.raccount = raccount;
	}
	
	public int getAmount() {
		return amount;
	}
	
	public void setAmount(int amount) {
		this.amount = amount;
	}

	
}
